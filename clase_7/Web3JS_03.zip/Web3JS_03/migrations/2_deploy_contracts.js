var Votacion = artifacts.require("Votacion");

module.exports = async function (deployer, network, accounts) {
  let futura = Votacion.new(['Carolina','Mario','Leonardo','Joaquín']);

  let instanciaVotacion = await futura;
  //printeamos la dirección
  console.log('Esto es para probar, address: ');
  console.log(instanciaVotacion.address);
}
