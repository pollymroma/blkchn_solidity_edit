import "../styles/app.css";

import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'

//IMPORTANTE: el artefacto proviene del .json y no del .sol!
import votacion_artifacts from '../../build/contracts/Votacion.json'

var Votacion = contract(votacion_artifacts);

//NOTA: ejecutar contractInstance.address
// para obtener el address del contrato y pegarlo para reemplazar el siguiente

var contractInstance = Votacion.at('0x60575bac14f434fcd717dd625b2a0a0b9191ee63');
var candidatos = {"Carolina": "option-1", "Mario": "option-2", "Leonardo": "option-3", "Joaquin": "option-4"};

window.App = {
  start: function() {
    var self = this;

    Votacion.setProvider(web3.currentProvider);
    Votacion.defaults({from: web3.eth.coinbase});
console.log('start function');
    //Primer paso, obtención de cuentas
    web3.eth.getAccounts(function(err, accs) {
        if (err != null) {
          alert("Error al querer obtener cuentas. No se podrá continuar");
          return;
        }
        if (accs.length == 0) {
          alert("No hay cuentas disponibles");
          return;
        }
      });

      var candidatosArray = Object.keys(candidatos);
      //Recorremos el array de candidatos
      for (var i = 0; i < candidatosArray.length; i++) {
        let nombreCandidato = candidatosArray[i];//tomamos el nombre
        //Refrescamos la UI del candidato
        self.actualizarVotosCandidato(nombreCandidato);
      }
    },

  votarCandidato: async function(message) {
    console.log('votar candidato');
    var self = this;

    var nombreCandidato = $("#candidato").val();
    var address = web3.eth.coinbase;
    //Aquí estamos enviando nuestro voto a la blockchain
    var voto = await contractInstance.voteForCandidate(nombreCandidato, {from: address});

    await self.actualizarVotosCandidato(nombreCandidato);

    },

  actualizarVotosCandidato: function(nombreCandidato) {
    let div_id = candidatos[nombreCandidato];
    //Aquí ya estamos llamando Al contrato!!
    console.log('actualizar votos candidato');
      var votosPromise = contractInstance.totalVotesFor.call(nombreCandidato);
      //Al ser una promesa, tendremos que aplicarle el then para poder hacer
      //lo que queremos con el resultado
      votosPromise.then(votos => $("#"+ div_id).html(votos.toString()));
    }
};

window.addEventListener('load', function(){
  if (typeof web3 !== 'undefined') {
     console.warn("Usando web3 desde origen externo")
     window.web3 = new Web3(web3.currentProvider);
   } else {
     console.warn("No se detectó un web3 provider");
     window.web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
   }

   App.start();
});
